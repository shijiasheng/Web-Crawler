# 包含文件说明

```
─Assignment1
|  ├─操作步骤说明文档.md
|  ├─操作步骤说明文档.pdf
│  ├─1GetID 处理原始的txt文件，并从中截取productId的信息代码
│  ├─2WebCrawler 爬取网页信息代码
│  ├─3GetData 提取出所需要的信息代码
│  ├─4ProcessData 对于数据清洗筛选代码
│  └─data
│      ├─InitialData 3中提取出来的数据
│      └─ProcessData20201026 清洗筛选后的数据（包括电影和系列两个）
```

